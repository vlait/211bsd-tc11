/*
 *	tc11 autoconfig support jan3/2020 vla
*/
#include "param.h"
#include "../machine/autoconfig.h"
#include "../machine/machparam.h"

tcprobe(addr,vector)
	u_int *addr;
	int vector;
{
	extern int errno;
	
	errno=0;
	grab(addr);
	return(errno ? ACP_NXDEV : ACP_EXISTS);
}
