
/*
 * TC-11 tu56 DECtape driver 
 *	0.3 POC
 *	 
 *	hacked from v7 tc driver to run on 211bsd
 *	note the blocksize is *512* here, not 256
 *	!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
 *	!!! WILL LIKELY NOT WORK ON A REAL PDP11 AS IS 		!!!
 *	!!! MAY CAUSE SIGNIFICANT DATA LOSS!!!!!!!!!!!!!!!!!!!!!!!!
 *	!!! PLEASE DO NOT USE WITHOUT BACKING UP ALL YOUR FILES !!!
 *	!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
 *	03Jan2019/vla 
 *	-added autoconfig routines (not sure if necessary) 
 *	-added disktab support (not really tested)
 */
#include "tc.h"
#if NTC > 0
#include "param.h"
#include "buf.h"
#include "machine/seg.h"
#include "conf.h"
#include "ioctl.h"
#include "tty.h"
#include "errno.h"
#include "map.h"
#include "uba.h"
#include "dir.h"
#include "user.h"
#include "disk.h"
#include "syslog.h"
#include "stat.h"

struct device {
	int	tccsr;
	union wb {
		int	w;
		char	b[2];
	} tccm;
	int	tcwc;
	int	tcba;
	int	tcdt;
};

struct	buf	tctab;
char	tcper[8];
struct	dkdevice tc_dk[8];
#define TCUNIT(x) (dkunit(x) & 7)

int tcstrategy();
struct device *TCADDR;

#define	TCADDRDFLT	((struct device *) 0177340)
#define	NTCBLK	578

#define	TAPERR	0100000
#define	TREV	04000
#define	READY	0200
#define	IENABLE	0100
#define	UPS	0200
#define	ENDZ	0100000
#define	BLKM	02000
#define	ILGOP	010000
#define	SELERR	04000

#define	SAT	0
#define	RNUM	02
#define	RDATA	04
#define	SST	010
#define	WDATA	014
#define	GO	01

#define	SFORW	1
#define	SREV	2
#define	SIO	3

tcattach(addr,unit)
        register struct device *addr;
{
        if(unit != 0)
                return(0);
        if(addr && (fioword(addr) != -1)) {
                TCADDR = addr;
                return(1);
        }
        TCADDR = (struct device *)NULL;
        return(0);
}

tcopen(dev,flag,mode)
	dev_t dev;
	int flag;
	int mode;
{
	int mask;
	register struct dkdevice *disk;

	if(fioword(TCADDR) == -1)
		return(ENXIO);
	if(dkpart(dev) > 0)
		return(ENXIO);
	if(TCUNIT(dev) > 7)
		return(ENXIO);	

	disk = &tc_dk[TCUNIT(dev)];
	
	while(disk->dk_flags & (DKF_OPENING | DKF_CLOSING))
		sleep(disk,PRIBIO);
	
	if (disk->dk_label == 0)
		disk->dk_label = disklabelalloc();
	if (disk->dk_openmask == 0)
	{
		disk->dk_openmask |= DKF_OPENING;
		tcgetinfo(disk,dev);
		disk->dk_openmask &= ~DKF_OPENING;
	}		
	if(mode == S_IFCHR)
		disk->dk_copenmask |= 1;
	else if(mode == S_IFBLK)	
		disk->dk_bopenmask |= 1;
	else
		return(EINVAL);
	disk->dk_openmask |= 1;
	return(0);
}
tcclose(dev, flag, mode)
	register dev_t dev;
	int flag, mode;
{
	register struct dkdevice *disk;
	int s;

	disk = &tc_dk[TCUNIT(dev)];

	if(mode == S_IFCHR)
		disk->dk_copenmask &= ~1;
	else if(mode == S_IFBLK)
		disk->dk_bopenmask &= ~1;
	else
		return(EINVAL);
	disk->dk_openmask = disk->dk_bopenmask | disk->dk_copenmask;
	if(disk->dk_openmask == 0)
	{
		/* we should probably wait here for pending transfers
		 * but it will require a small rewrite 
		*/	
		wakeup(disk);
	}	
	tcper[TCUNIT(dev)&07] = 0;

	return(0);	
		
}

tcstrategy(bp)
register struct buf *bp;
{
	int s;
	
	if(bp->b_blkno >= NTCBLK || tcper[TCUNIT(bp->b_dev)&07]) {
		bp->b_flags |= B_ERROR;
		bp->b_error = EINVAL;
		iodone(bp);
		return;
	}

	mapalloc(bp);
	bp->av_forw = (struct buf *) NULL;
	s=splbio();

	if (tctab.b_actf ==NULL)
		tctab.b_actf = bp;
	else
		tctab.b_actl->av_forw = bp;

	tctab.b_actl = bp;

	if (tctab.b_active == NULL)
		tcstart();

	splx(s);
}

tcstart()
{
	register struct buf *bp;
	register int com;
	register union wb *tccmp;
	struct dkdevice *disk;
	int unit;

loop:
	tccmp = &TCADDR->tccm;

	if ((bp = tctab.b_actf) == NULL)
	{
		return;
	}

	if(tcper[TCUNIT(bp->b_dev)&07]) {
		if((tctab.b_actf = bp->av_forw) == 0)
			tccmp->b[0] = SAT|GO;
		bp->b_flags |= B_ERROR;
		iodone(bp);
		goto loop;
	}

	if ((tccmp->b[1]&07) != TCUNIT(bp->b_dev))
		tccmp->b[0] = SAT|GO;

	tctab.b_errcnt = 20;
	tctab.b_active = SFORW;
	com = (TCUNIT(bp->b_dev)<<8) | IENABLE|RNUM|GO;

	if ((TCADDR->tccsr & UPS) == 0) {
		com |= TREV;
		tctab.b_active = SREV;
	}
	tccmp->w = com;
}

tcintr()
{
	register struct buf *bp;
	register union wb *tccmp;
	register int *tcdtp;

	tccmp = &TCADDR->tccm;
	tcdtp = &TCADDR->tccsr;
	
	bp = tctab.b_actf;
	if(bp->b_blkno >= NTCBLK) {
		log(LOG_NOTICE,"tc0 err, seek out of bounds %d\n",bp->b_blkno);
		bp->b_flags |= B_ERROR;
		goto done;	
		}
	if (tccmp->w&TAPERR) {
		if((*tcdtp&(ENDZ|BLKM)) == 0){
			log(LOG_NOTICE,"tc0 err, %d tccmp %d\n",*tcdtp ,tccmp->w);	
			bp->b_flags |= B_ERROR;
			goto done;	
			}
		if(*tcdtp & (ILGOP|SELERR)) {
			tcper[TCUNIT(bp->b_dev)&07]++;
			tctab.b_errcnt = 0;
		}
		tccmp->w &= ~TAPERR;
		if (--tctab.b_errcnt == 0) {
			bp->b_flags |= B_ERROR;
			goto done;
		}
		if (tccmp->w&TREV) {
		setforw:
			tctab.b_active = SFORW;
			tccmp->w &= ~TREV;
		} else {
		setback:
			tctab.b_active = SREV;
			tccmp->w |= TREV;
		}
		tccmp->b[0] = IENABLE|RNUM|GO;
		return;
	}
	tcdtp = &TCADDR->tcdt;
	switch (tctab.b_active) {

	case SIO:
	done:
		tctab.b_active = 0;
		if (tctab.b_actf = bp->av_forw)
			tcstart();
		else
			TCADDR->tccm.b[0] = SAT|GO;
		iodone(bp);
		return;

	case SFORW:
		if (*tcdtp > bp->b_blkno)
			goto setback;
		if (*tcdtp < bp->b_blkno)
			goto setforw;
		*--tcdtp = (int)bp->b_un.b_addr;	/* core address */
		*--tcdtp = -(bp->b_bcount>>1);
		tccmp->b[0] = ((bp->b_xmem & 03) << 4) | IENABLE|GO
		    | (bp->b_flags&B_READ?RDATA:WDATA);
		tctab.b_active = SIO;
		return;

	case SREV:
		if (*tcdtp+3 > bp->b_blkno)
			goto setback;
		goto setforw;
	}
}

daddr_t
tcsize(dev)
	register dev_t dev;
	{
		/* 
		only 1 partition spanning entire tape , not sure this should 
		be here though.
		*/
		return(NTCBLK);
	}

tcioctl(dev, cmd, data, flag)
	dev_t dev;
	int cmd;
	caddr_t data;
	int flag;
{
	register int error;
	struct dkdevice *disk = &tc_dk[TCUNIT(dev)];

	error = ioctldisklabel(dev, cmd, data, flag, disk, tcstrategy);
	return(error);
}

void tcdfltlbl(disk, lp, dev)
	struct dkdevice *disk;
	register struct disklabel *lp;
	dev_t dev;
{
	register struct partition *pi = &lp->d_partitions[0];

	bzero(lp, sizeof(*lp));
	lp->d_secsize =512;
	lp->d_nsectors = 4;
	lp->d_ntracks = 4;
	lp->d_ncylinders = 36;
	lp->d_secpercyl = 4*4;
	lp->d_rpm = 3600;
	lp->d_npartitions = 1;
	pi->p_size = 576;
	pi->p_offset = 0;
	pi->p_fstype = FS_V71K;
	pi->p_frag = 1;
	pi->p_fsize = 1024;

	bcopy(pi, disk->dk_parts, sizeof(lp->d_partitions));
}

void tcgetinfo(disk, dev)
	register struct dkdevice *disk;
	dev_t dev;
{
	struct disklabel locallabel;
	char *msg;
	register struct disklabel *lp = &locallabel;
	tcdfltlbl(disk,lp,dev);
	msg = readdisklabel((dev & ~7) | 0,tcstrategy, lp);
	if(msg != 0)
	{
		tcdfltlbl(disk,lp,dev);
		/* not enabled since the device could be used as a reg tape
		log(LOG_NOTICE, "tc%da is entire disc %s\n",dkunit(dev), msg);
		*/
	}
	mapseg5(disk->dk_label, LABELDESC)
	bcopy(lp, (struct disklabel *)SEG5, sizeof(struct disklabel));
	normalseg5();
	bcopy(lp->d_partitions, disk->dk_parts, sizeof(lp->d_partitions));
	return;
}
#endif
